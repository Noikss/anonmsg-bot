# AnonMsg Bot

Телеграм-бот для анонимных сообщений. Генерируешь личную ссылку — люди пишут анонимно, ты получаешь всё в боте.

## Функции

- Анонимная отправка текста, фото, голосовых, видео, файлов, стикеров, кружков
- Блокировка нежелательных отправителей
- Статистика сообщений
- Админ-команда `/stats`

## Установка

1. Скопируй `.env.example` в `.env` и заполни:
```
BOT_TOKEN=токен от @BotFather
ADMIN_ID=твой Telegram ID
```

2. Установи зависимости:
```bash
pip install -r requirements.txt
```

3. Запусти:
```bash
python bot.py
```

## Структура

```
anonmsg_bot/
├── bot.py              # Точка входа
├── config.py           # Конфиг из .env
├── requirements.txt
├── .env.example
├── database/
│   └── db.py           # SQLite, все запросы
├── handlers/
│   ├── start.py        # /start, deep links
│   ├── message.py      # Отправка сообщений, callbacks
│   └── admin.py        # Админ команды
├── keyboards/
│   └── inline.py       # Все клавиатуры
└── utils/
    └── helpers.py      # Генерация токенов, хэширование
```

## Деплой на BotHost

1. Загрузи все файлы
2. Укажи `bot.py` как точку входа
3. Добавь переменные окружения из `.env`
